package com.spring.user;
import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
@Service

public class UserDAO {
	
	Criteria criteria = null;
	@Autowired
	public SessionFactory sessionFactory;
	@Transactional 
	public void insertUser(User user)
	{
		Address address = user.getAddress();
		sessionFactory.getCurrentSession().save(address);
		sessionFactory.getCurrentSession().save(user);
	}
	@Autowired
	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}
	@Autowired
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	@Transactional
	public User checkUser(String name,String password)
	{
		// User u= (User)sessionFactory.getCurrentSession().get(User.class,name);
	//	String hql = "FROM Employee E WHERE E.id = :employee_id";
	//	Query query = session.createQuery(hql);
	//	query.setParameter("employee_id",10);
	//	List results = query.list();
	//	System.out.println("inside DAO");
	//	 return (User)sessionFactory.getCurrentSession().createQuery("from User U where U.userName=:name").setString("name",name).uniqueResult();
		// return u;
		 criteria = sessionFactory.getCurrentSession().createCriteria(User.class);
		criteria.add(Restrictions.eq("userName", name));
		criteria.add(Restrictions.eq("password",password));
		return (User)criteria.uniqueResult();
	}
	
	@Transactional
	public void insertMedicalHistory(MedicalHistory medicalHistory)
	{
		Medication medication = medicalHistory.getMedication();
		sessionFactory.getCurrentSession().save(medication);
		sessionFactory.getCurrentSession().save(medicalHistory);
	}
	
	/*@Transactional
	public User getLastUser()
	{
		criteria = sessionFactory.getCurrentSession().createCriteria(User.class);
		//criteria.setProjection(Projections.max("e.encounterId"));
		criteria.addOrder(Order.desc("id"));
	//	criteria.setFirstResult(1);
		criteria.setMaxResults(1);
		return  (User) criteria.uniqueResult();
	}*/
	@Transactional
	public void insertMedication(Medication medication)
	{
		sessionFactory.getCurrentSession().save(medication);
	}
	@Transactional
	public void insertHospital(Hospital hospital)
	{
		Address address = hospital.getAddress();
		User user = hospital.getUser();
		sessionFactory.getCurrentSession().save(address);
		sessionFactory.getCurrentSession().save(hospital);
	}
	@Transactional
	public Hospital getHospital(User user)
	{
		criteria = sessionFactory.getCurrentSession().createCriteria(Hospital.class);
		criteria.add(Restrictions.eq("user", user));
		return (Hospital) criteria.uniqueResult();
	}
}
