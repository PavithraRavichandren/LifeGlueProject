package com.spring.user;
import com.spring.user.UserDAO;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

@Controller
@SessionAttributes({"user"})
public class UserController {
	
	@Autowired
	private UserDAO userDAO;
	@Autowired
	private HttpSession session;
	
	

	
	@RequestMapping("/submitPatient")
	public ModelAndView submitPatient(@RequestParam("fullname")String fullname,/*@RequestParam("dob")Date dob,*/@RequestParam("height")Integer height,@RequestParam("weight")Integer weight,
			@RequestParam("bloodGroup")String bloodGroup,@RequestParam("cholesterol")Integer cholesterol,@RequestParam("pressure")Integer pressure,@RequestParam("sugar")Integer sugar,
			@RequestParam("conditions")String conditions,@RequestParam("symptoms")String symptoms,@RequestParam("Gender")String gender,@RequestParam("tobacco")String tobacco,
			@RequestParam("drugs")String drugs,@RequestParam("alcohol")String alcohol,
			@RequestParam("purpose1")String purpose1,@RequestParam("medication1")String medication1,
			@RequestParam("hospital1")String hospital1,/*@RequestParam("date1")Date date1,*/@RequestParam("comments")String comments, @ModelAttribute User user)
	{
		
		Medication medication = new Medication(purpose1,medication1,hospital1,null);
		//User u = (User) session.getAttribute("user");
		System.out.println(conditions);
		MedicalHistory medicalHistory = new MedicalHistory(fullname,null,height,weight,bloodGroup,cholesterol,pressure,sugar,conditions,symptoms,gender,tobacco,drugs,alcohol,comments,user,medication);
		userDAO.insertMedicalHistory(medicalHistory);
		return new ModelAndView("home");
	}
	
	
	
	/*public void editCustomer(@RequestParam(value = "checkboxName", required = false) String checkboxValue) 
{
  if(checkboxValue != null)
  {
    System.out.println("checkbox is checked");
  }
  else
  {
    System.out.println("checkbox is not checked");
  }*/
	
	
	@RequestMapping("/index")
	public String index() {
		//System.out.println("ControllerUser");
		return "index";
	}
	
	@RequestMapping("/signup")
	public String signup() {
		//System.out.println("ControllerUser");
		return "signup";
	}
	
	@RequestMapping("/hospitalLogin")
	public ModelAndView hospitalLogin(@RequestParam("hospital_name")String hospital_name,@RequestParam("hospital_address")String hospital_address,@RequestParam("hospital_email")String hospital_email,@RequestParam("hospital_number")String hospital_number
			,@ModelAttribute User user)
	{
		String[] arr = hospital_address.split(",");
		Address address1 = new Address(arr[0],arr[1],arr[2],arr[3],Long.parseLong(arr[4]));
		// User user = (User) request.getAttribute("user");
		//User user = userDAO.getLastUser();
	    Hospital hospital = new Hospital(hospital_name,hospital_email,hospital_number,address1,user);
	    userDAO.insertHospital(hospital);
	    return new ModelAndView("hospitalHome","Hospital",hospital);
	}
	
	@RequestMapping("/insertUser")
	public ModelAndView signup(@RequestParam("name")String name,@RequestParam("email")String email,@RequestParam("role")String role,@RequestParam("password")String password,
			@RequestParam("mobile")String mobile,@RequestParam("address")String address,ModelMap modelMap) {
		String[] arr = address.split(",");
		Address address1 = new Address(arr[0],arr[1],arr[2],arr[3],Long.parseLong(arr[4]));
		User user = new User(name,email,role,password,mobile,address1);
		userDAO.insertUser(user);
		modelMap.addAttribute(user);
		if(role.equals("patient"))
		return new ModelAndView("home","user",user);
		else
			return new ModelAndView("hospital","user",user);
	}
	
	@RequestMapping("/getAllPatients")
	public ModelAndView getAllPatients()
	{
		
		     return new ModelAndView("");
	}
	
	@RequestMapping("/login")
	public String login() {
		//System.out.println("ControllerUser");
		return "login";
	}

	
	@RequestMapping("/checkLogin")
	public ModelAndView checkLogin(@RequestParam("name")String name,@RequestParam("password")String password,ModelMap modelMap)
	{
		
		User user = userDAO.checkUser(name,password);
		if(user==null)
		return new ModelAndView("index");
		else
			modelMap.addAttribute(user);
    	if(user.getRole().equals("patient"))
    		return new ModelAndView("home");
    if(user .getRole().equals("medical_staff"))
    {
    	//Hospital hospital = userDAO.getHospital(u.getId());
    	Hospital hospital = userDAO.getHospital(user);
    	if(hospital!=null)
    	return new ModelAndView("hospitalHome","Hospital",hospital);
    	else
    		return new ModelAndView("index");
    }
			
		else 
			return new ModelAndView("index");
}
	
	@RequestMapping("/UploadMedicalHistory")
	public String UploadMedicalHistory()
	{
		return "patientform";
	}
}