package com.spring.user;
import java.sql.Date;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.FetchMode;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
@Service

public class UserDAO {
	
	Criteria criteria = null;
	@Autowired
	public SessionFactory sessionFactory;
	@Transactional 
	public void insertUser(User user)
	{
		Address address = user.getAddress();
		sessionFactory.getCurrentSession().save(address);
		sessionFactory.getCurrentSession().save(user);
	}
	@Autowired
	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}
	@Autowired
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	@Transactional
	public User checkUser(String name,String password)
	{
		 criteria = sessionFactory.getCurrentSession().createCriteria(User.class);
		criteria.add(Restrictions.eq("userName", name));
		criteria.add(Restrictions.eq("password",password));
		return (User)criteria.uniqueResult();
	}
	
	@Transactional
	public void insertMedicalHistory(MedicalHistory medicalHistory,List<Medication> list)
	{
		for(Medication m:list)
		sessionFactory.getCurrentSession().saveOrUpdate(m);
		sessionFactory.getCurrentSession().saveOrUpdate(medicalHistory);
	}
	
	@Transactional
	public void insertMedication(Medication medication)
	{
		sessionFactory.getCurrentSession().saveOrUpdate(medication);
	}
	@Transactional
	public void insertHospital(Hospital hospital)
	{
		Address address = hospital.getAddress();
		User user = hospital.getUser();
		sessionFactory.getCurrentSession().saveOrUpdate(address);
		sessionFactory.getCurrentSession().saveOrUpdate(hospital);
	}
	@Transactional
	public Hospital getHospital(User user)
	{
		criteria = sessionFactory.getCurrentSession().createCriteria(Hospital.class);
		criteria.add(Restrictions.eq("user", user));
		return (Hospital) criteria.uniqueResult();
	}
	
	@Transactional
	public Boolean checkPatientRecord(User user)
	{
		criteria = sessionFactory.getCurrentSession().createCriteria(MedicalHistory.class);
		criteria.add(Restrictions.eq("user", user));
	    List patientRecordList = criteria.list();
	//	MedicalHistory medicalHistory = (MedicalHistory) criteria.uniqueResult();
		if(patientRecordList.isEmpty())
			return true;
		else
			return false;
	}
   @Transactional
	public List getPatientByDate(Hospital hospital,java.sql.Date d)
	{
		criteria = sessionFactory.getCurrentSession().createCriteria(Medication.class);
		criteria.add(Restrictions.eq("hospitalName", hospital.getHospitalName()));
		criteria.add(Restrictions.eq("treatmentDate", d));
		System.out.println(d);
		return criteria.list();
	}
   @Transactional
   public List getPatientByName(Hospital hospital,String name)
   {
	   criteria = sessionFactory.getCurrentSession().createCriteria(Medication.class).createAlias("medicalHistory","medicalHistory")
			   .add(Restrictions.eq("medicalHistory.fullName", name));
	   criteria.add(Restrictions.eq("hospitalName", hospital.getHospitalName()));
	   return criteria.list();
   }
   @Transactional
   public List getPatientById(Hospital hospital,Integer id)
   {
	   
	   criteria = sessionFactory.getCurrentSession().createCriteria(Medication.class).createAlias("user","user");
			   criteria.add(Restrictions.eq("hospitalName", hospital.getHospitalName()));
			   criteria.add(Restrictions.eq("user.id", id));
	 
	   return criteria.list();

   }
	@SuppressWarnings("unchecked")
	@Transactional 
	public List getAllPatients(Hospital hospital)
	{
		/*criteria = sessionFactory.getCurrentSession().createCriteria(Hospital.class);
		criteria.add(Restrictions.eq("user", user));*/
		criteria = sessionFactory.getCurrentSession().createCriteria(Medication.class);
		criteria.add(Restrictions.eq("hospitalName", hospital.getHospitalName()));
		return  criteria.list();
	}
	
}
