package com.spring.user;
import com.spring.user.UserDAO;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

@Controller
@SessionAttributes({"user"})
public class UserController {
	
	@Autowired
	private UserDAO userDAO;
	@Autowired
	private HttpSession session;
	
	

	
	@RequestMapping("/submitPatient")
	public ModelAndView submitPatient(@RequestParam("fullname")String fullname,/*@RequestParam("dob")Date dob,*/@RequestParam("height")Integer height,@RequestParam("weight")Integer weight,
			@RequestParam("bloodGroup")String bloodGroup,@RequestParam("cholesterol")Integer cholesterol,@RequestParam("pressure")Integer pressure,@RequestParam("sugar")Integer sugar,
			@RequestParam("conditions")String conditions,@RequestParam("symptoms")String symptoms,@RequestParam("Gender")String gender,@RequestParam("tobacco")String tobacco,
			@RequestParam("drugs")String drugs,@RequestParam("alcohol")String alcohol,
			@RequestParam("purpose1")String purpose1,@RequestParam("medication1")String medication1,@RequestParam("hospital1")String hospital1,
			@RequestParam("purpose2")String purpose2,@RequestParam("medication2")String medication2,@RequestParam("hospital2")String hospital2,
			@RequestParam("purpose3")String purpose3,@RequestParam("medication3")String medication3,@RequestParam("hospital3")String hospital3,
			@RequestParam("purpose4")String purpose4,@RequestParam("medication4")String medication4,@RequestParam("hospital4")String hospital4,
		/*	@RequestParam("date1")Date date1,@RequestParam("date1")Date date2,@RequestParam("date1")Date date3,@RequestParam("date1")Date date4,*/
			@RequestParam("comments")String comments, @ModelAttribute User user)
	{
		MedicalHistory medicalHistory = new MedicalHistory(fullname,null,height,weight,bloodGroup,cholesterol,pressure,sugar,conditions,symptoms,gender,tobacco,drugs,alcohol,comments,user);

		ArrayList<Medication> list = new ArrayList<Medication>();
		if((purpose1!="")&&(medication1!="")&&(hospital1!=""))
		list.add(new Medication(purpose1,medication1,hospital1,null,medicalHistory));
		if((purpose2!="")&&(medication2!="")&&(hospital2!=""))
			list.add(new Medication(purpose2,medication2,hospital2,null,medicalHistory));
		if((purpose3!="")&&(medication3!="")&&(hospital3!=""))
			list.add(new Medication(purpose3,medication3,hospital3,null,medicalHistory));
		if((purpose4!="")&&(medication4!="")&&(hospital4!=""))
			list.add(new Medication(purpose4,medication4,hospital4,null,medicalHistory));
		
		//User u = (User) session.getAttribute("user");
		System.out.println(conditions);
			userDAO.insertMedicalHistory(medicalHistory,list);
		return new ModelAndView("home");
	}
	
	
	@RequestMapping("/index")
	public String index() {
		//System.out.println("ControllerUser");
		return "index";
	}
	
	@RequestMapping("/home")
	public String home() {
		//System.out.println("ControllerUser");
		return "home";
	}
	
	
	
	
	@RequestMapping("/signup")
	public String signup() {
		//System.out.println("ControllerUser");
		return "signup";
	}
	
	@RequestMapping("/hospitalLogin")
	public ModelAndView hospitalLogin(@RequestParam("hospital_name")String hospital_name,@RequestParam("hospital_address")String hospital_address,@RequestParam("hospital_email")String hospital_email,@RequestParam("hospital_number")String hospital_number
			,@ModelAttribute User user)
	{
		String[] arr = hospital_address.split(",");
		Address address1 = new Address(arr[0],arr[1],arr[2],arr[3],Long.parseLong(arr[4]));
		// User user = (User) request.getAttribute("user");
		//User user = userDAO.getLastUser();
	    Hospital hospital = new Hospital(hospital_name,hospital_email,hospital_number,address1,user);
	    userDAO.insertHospital(hospital);
	    return new ModelAndView("hospitalHome","Hospital",hospital);
	}
	
	@RequestMapping("/insertUser")
	public ModelAndView signup(@RequestParam("name")String name,@RequestParam("email")String email,@RequestParam("role")String role,@RequestParam("password")String password,
			@RequestParam("mobile")String mobile,@RequestParam("address")String address,ModelMap modelMap) {
		String[] arr = address.split(",");
		Address address1 = new Address(arr[0],arr[1],arr[2],arr[3],Long.parseLong(arr[4]));
		User user = new User(name,email,role,password,mobile,address1);
		User u = userDAO.checkUser(name,password);
		if(u==null)
		{
		userDAO.insertUser(user);
		modelMap.addAttribute(user);
		if(role.equals("patient"))
		return new ModelAndView("home","user",user);
		else
			return new ModelAndView("hospital","user",user);
		}
		else
			return new ModelAndView("login","error","You Already Hava an account...Please try again with other email!");
	}
	
	@RequestMapping("/getAllPatients")
	public ModelAndView getAllPatients(@ModelAttribute User user)
	{
		     Hospital h = userDAO.getHospital(user);
		     @SuppressWarnings("unchecked")
			List<Medication> list = (List<Medication>) userDAO.getAllPatients(h);
		     return new ModelAndView("getAllPatients","list",list);
	}
	
	@RequestMapping("/login")
	public String login() {
		//System.out.println("ControllerUser");
		return "login";
	}

	
	
	@RequestMapping("/checkLogin")
	public ModelAndView checkLogin(@RequestParam("name")String name,@RequestParam("password")String password,ModelMap modelMap)
	{
		
		User user = userDAO.checkUser(name,password);
		if(user==null)
		return new ModelAndView("login","error","UserName or Password may be wrong!!");
		else
			modelMap.addAttribute(user);
    	if(user.getRole().equals("patient"))
    		return new ModelAndView("home","error","UserName or Password may be wrong!!");
    if(user .getRole().equals("medical_staff"))
    {
    	//Hospital hospital = userDAO.getHospital(u.getId());
    	Hospital hospital = userDAO.getHospital(user);
    	if(hospital!=null)
    	return new ModelAndView("hospitalHome","Hospital",hospital);
    	else
    		return new ModelAndView("index");
    }
			
		else 
			return new ModelAndView("login","error","UserName or Password may be wrong!!");
}
	
	@RequestMapping("/patientform")
	public String patientform()
	{
		return "patientform";
	}
	
	@RequestMapping("/UploadMedicalHistory")
	public String UploadMedicalHistory(@ModelAttribute User user)
	{
		
		Boolean b = userDAO.checkPatientRecord(user);
		if(b==true)
		return "patientform";
		else
		return "errorupload";
	}
}