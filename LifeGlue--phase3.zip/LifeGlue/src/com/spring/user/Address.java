package com.spring.user;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Address")
public class Address implements Serializable{
    @Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
    private Integer id;
	@Column(name = "streetNumber")
    private String streetNumber;
	@Column(name = "area")
    private String area;
	@Column(name="city")
	private String city;
	@Column(name = "location")
	private String location;
	@Column(name="pincode")
	private Long pincode;

	public Address() {
	}

	public Address(String streetNumber, String area, String city, String location, Long pincode) {
		super();
		this.streetNumber = streetNumber;
		this.area = area;
		this.city = city;
		this.location = location;
		this.pincode = pincode;
	}
	}
